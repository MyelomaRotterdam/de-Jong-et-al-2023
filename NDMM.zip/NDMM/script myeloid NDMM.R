# --------------------------------------------------- #
# Analysis of scRNA sequencing data as described in de Jong et al. 2023
# Script by Madelon de Jong, optimized for speed by Mathijs Sanders
# Dept. of Hematology, Erasmus MC Cancer Institute, Rotterdam, the Netherlands
# --------------------------------------------------- #

# --------------------------------------------------- #
# READ-ME (IMPORTANT)
# This script is meant to generate the major myeloid object, containing progenitors, monocytes and neutrophils.
# In the paper, these three subsets are separated for individual analysis using selection of barcodes (available on Github), followed by reprocessing.
# For reprocessing steps, a different function that entails barcode selection is required.
# This script is separately available on github, named 'alternative_preprocessing.R'
# --------------------------------------------------- #

# --------------------------------------------------- #
# Loading libraries
# --------------------------------------------------- #

pacman::p_load('Seurat', 'future', 'parallel', 'cowplot', 'ggplot2', 'dplyr')

options(future.rng.onMisuse="ignore")
options(future.globals.maxSize = 1e4 * 1024^2)
options(future.fork.enable = TRUE)

# --------------------------------------------------- #
# Function for loading in objects
# --------------------------------------------------- #

loadSeuratObject <- function(idx, projectName, matLoc, bcLoc, selectionCriteria, details) {
  info <- structure(selectionCriteria[idx, ], names = colnames(selectionCriteria))
  currentDetails <- structure(details[idx, ], names = colnames(details))
  so <- Read10X(data.dir = matLoc[idx])
  so <- CreateSeuratObject(counts = so, min.cells = 3, min.features = 200, project = projectName)
  so <- AddMetaData(so, PercentageFeatureSet(so, pattern = "^MT-"), col.name = "percent.mito")
  so <- subset(x = so, subset = nFeature_RNA > info$nFeature_RNA_lower & nFeature_RNA < info$nFeature_RNA_higher & nCount_RNA > info$nCount_RNA_lower & nCount_RNA < info$nCount_RNA_higher & percent.mito < info$percent.mito)
  so <- NormalizeData(object = so, normalization.method = "LogNormalize", scale.factor = 1e4)
  so <- FindVariableFeatures(object = so, selection.method = "vst", nfeatures = 2000)
  so$source <- currentDetails$Source
  so$patient <- currentDetails$Patient
  so
}

# --------------------------------------------------- #
# Function for defining number of cores
# --------------------------------------------------- #

mcPredefined <- function(threads) {
  function(...) {
    mclapply(..., mc.cores = threads)
  }
}

# --------------------------------------------------- #
# Object information
# --------------------------------------------------- #

projectName <- 'Myeloid'
threads <- 10
matLoc <- readLines('~/samples.txt')
selectionCriteria <- read.table('~/selection.txt', header = TRUE)
details <- read.table('~/details.txt', header = TRUE)

# --------------------------------------------------- #
# Making objects
# --------------------------------------------------- #

so.list <- ifelse(threads > 1, get('mcPredefined')(threads), get('lapply'))(seq(matLoc), loadSeuratObject, projectName, matLoc, bcLoc, selectionCriteria, details)

# --------------------------------------------------- #
# Integration 1 
# --------------------------------------------------- #

plan(strategy = 'multicore', workers = 15)

reference.list <- so.list[c(1:3, 6:8)]
myeloma.anchors <- FindIntegrationAnchors(object.list = reference.list, dims = 1:30)
myeloma.integrated <- IntegrateData(anchorset = myeloma.anchors, dims = 1:30)

# --------------------------------------------------- #
# Integration 2 
# --------------------------------------------------- #

plan(strategy = 'multiprocess', workers = 15)

reference.list <- so.list[c(4,5,9,10)]
control.anchors <- FindIntegrationAnchors(object.list = reference.list, dims = 1:30)
control.integrated <- IntegrateData(anchorset = control.anchors, dims = 1:30)

# --------------------------------------------------- #
# Integration 3
# --------------------------------------------------- #

plan(strategy = 'multiprocess', workers = 15)

reference.list <- c(myeloma.integrated, control.integrated)
myeloma.anchors <- FindIntegrationAnchors(object.list = reference.list, dims = 1:30)
myeloma.integrated <- IntegrateData(anchorset = myeloma.anchors, dims = 1:30)

# --------------------------------------------------- #
# Post-processing
# --------------------------------------------------- #

# Removed unwanted admixture cells either by subsetting, or by selecting cells with Cellselector (vector called cells), and:
# cells_total <- myeloma.integrated@assays$RNA@counts@Dimnames
# cells_total <- cells_total[2]
# cells_total <- unlist(cells_total)
# cells_total <- cells_total[!cells_total %in% cells]
# myeloma.integrated <- subset(myeloma.integrated, cells = "cells_total")

DefaultAssay(object = myeloma.integrated) <- "integrated"
myeloma.integrated <- ScaleData(object = myeloma.integrated, verbose = F)
myeloma.integrated <- RunPCA(object = myeloma.integrated, verbose = F)
ElbowPlot(myeloma.integrated, ndims = 30, reduction = "pca")
myeloma.integrated <- RunUMAP(object = myeloma.integrated, reduction = "pca", dims = 1:15, return.model = T)
myeloma.integrated <- FindNeighbors(object = myeloma.integrated, dims = 1:15)
myeloma.integrated <- FindClusters(object = myeloma.integrated, resolution = 0.3)

# --------------------------------------------------- #
# For convenience: saving and loading after preprocessing
# --------------------------------------------------- #
saveRDS(myeloma.integrated, file = "~/total_myeloid.rds")
myeloma.integrated <- readRDS(file = "~/total_myeloid.rds")